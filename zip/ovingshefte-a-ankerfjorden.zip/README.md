# Øvingshefte A – Ankerfjorden kommune

De 30 dokumentene fra øvingshefte A (versjon 1.1), én PDF per dokument, og hele heftet (`Ovingshefte_A_innsyn_FIKTIV_v1.1.pdf`) med forside,
omtale av kommunen, oppgaver og dokumentoversikt. `oversikt.csv` viser nummer, filnavn, dato, tittel, saken
dokumentet hører til og siden i heftet.

## Lisens

© 2026 Magne Haagen Grøtting (<https://magnehg.net>).

Dokumentene er lisensiert under **Creative Commons Navngivelse-DelPåSammeVilkår 4.0 Internasjonal (CC BY-SA 4.0)**.
Hele lisensteksten står i `LICENSE.txt` og på <https://creativecommons.org/licenses/by-sa/4.0/legalcode.no>.

Du kan kopiere, dele, endre og bruke dokumentene til hva som helst, også kommersielt, så lenge du navngir kilden
og lisensen, sier fra om du har endret noe, og deler det du lager på samme vilkår.

Foreslått navngivelse:

> Øvingshefte A av Magne Haagen Grøtting (https://magnehg.net), lisensiert under CC BY-SA 4.0
> (https://creativecommons.org/licenses/by-sa/4.0/).

Ankerfjorden kommune og alle personer, virksomheter, tall og hendelser er **oppdiktet**.

**English summary:** Fictional practice documents for freedom-of-information training, © 2026 Magne Haagen Grøtting
(https://magnehg.net), licensed under CC BY-SA 4.0. See `LICENSE.txt`.
