# Paragrafkarusellen – dokumenter (PDF)

565 øvingsdokumenter fra Paragrafkarusellen, ett dokument per fil, i A4-PDF med søkbar tekst og vektorgrafikk.

- **001–500:** brev, notater, interne dokumenter og e-poster.
- **501–565:** SMS-tråder som utskrift fra tjenestetelefon, skrevet på 50 norske dialekter, multietnolekt og ti andre
  språkformer (svorsk, dansk-norsk, samiske og kvenske innslag og norsk som andrespråk).

`oversikt.csv` viser nummer, filnavn, tittel, avsender og (for SMS-ene) dialekten eller språkformen.

## Lisens

© 2026 Magne Haagen Grøtting (<https://magnehg.net>).

Dokumentene er lisensiert under **Creative Commons Navngivelse-DelPåSammeVilkår 4.0 Internasjonal (CC BY-SA 4.0)**.
Hele lisensteksten står i `LICENSE.txt` og på <https://creativecommons.org/licenses/by-sa/4.0/legalcode.no>
(sammendrag: <https://creativecommons.org/licenses/by-sa/4.0/deed.no>).

Du kan kopiere, dele, endre og bruke dokumentene til hva som helst, også kommersielt, så lenge du

- **navngir:** oppgir kilden og lisensen og sier fra om du har endret noe, og
- **deler på samme vilkår:** gir ut det du har laget av dokumentene under CC BY-SA 4.0 eller en forenlig lisens.

Foreslått navngivelse:

> Dokumenter fra Paragrafkarusellen av Magne Haagen Grøtting (https://magnehg.net), lisensiert under CC BY-SA 4.0
> (https://creativecommons.org/licenses/by-sa/4.0/).

## Om innholdet

Dokumentene er laget for å øve på offentleglova. Alle organer, personer, adresser, telefonnumre,
organisasjonsnumre, saksnumre og e-postadresser er **oppdiktet**. Likhet med virkelige personer eller
saker er tilfeldig. Filene inneholder ingen fasit.

Skrifttypene som er brukt (Source Sans 3, IBM Plex Mono, Liberation Sans og håndskriftene fra Google Fonts)
er lisensiert under SIL Open Font License 1.1, som tillater at de bygges inn i dokumenter.
Lisensen for dokumentene gjelder ikke selve skrifttypene.

---

**English summary:** These fictional practice documents from Paragrafkarusellen, © 2026 Magne Haagen Grøtting (https://magnehg.net),
are licensed under CC BY-SA 4.0. See `LICENSE.txt`. Attribute as shown above and share adaptations
under the same licence.
